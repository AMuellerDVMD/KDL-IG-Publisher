# ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.classCodes - Kontext: Archivierung, inkl. eVV - v2025.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.classCodes - Kontext: Archivierung, inkl. eVV**

## ConceptMap: ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.classCodes - Kontext: Archivierung, inkl. eVV 

| | |
| :--- | :--- |
| *Official URL*:http://dvmd.de/fhir/ConceptMap/kdl-ihe-classcode | *Version*:2025.0.1 |
| Active as of 2025-01-01 | *Computable Name*:ConceptMapKdlIheClasscode |
| **Copyright/Legal**: 2025 DVMD e.V. | |

 
Diese Ressource dient als Grundlage für die Zuordnung von KDL-Codes zu IHE-XDS DocumentEntry.classCodes (gemäß Spezifikation von IHE Deutschland e.V., siehe http://www.ihe-d.de/projekte/xds-value-sets-fuer-deutschland/). Grundlage ist der ANWENDUNGSFALL: DIGITALE ARCHIVIERUNG, inkl. aktuelle Anforderungen des Anhangs zur Anlage 1 der eVV. Das Reviewergebnis - zu diesem Mappingkonzept - von der IHE-AG IHE-XDS ValueSets aus 2023 wurde berücksichtigt. 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "kdl-ihe-classcode",
  "url" : "http://dvmd.de/fhir/ConceptMap/kdl-ihe-classcode",
  "version" : "2025.0.1",
  "name" : "ConceptMapKdlIheClasscode",
  "title" : "ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.classCodes - Kontext: Archivierung, inkl. eVV",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-01-01",
  "publisher" : "Der Fachverband für Dokumentation und Informationsmanagement in der Medizin (DVMD)",
  "contact" : [
    {
      "name" : "Der Fachverband für Dokumentation und Informationsmanagement in der Medizin (DVMD)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.dvmd.de"
        },
        {
          "system" : "email",
          "value" : "dvmd@dvmd.de"
        }
      ]
    }
  ],
  "description" : "Diese Ressource dient als Grundlage für die Zuordnung von KDL-Codes zu IHE-XDS DocumentEntry.classCodes (gemäß Spezifikation von IHE Deutschland e.V., siehe http://www.ihe-d.de/projekte/xds-value-sets-fuer-deutschland/). Grundlage ist der ANWENDUNGSFALL: DIGITALE ARCHIVIERUNG, inkl. aktuelle Anforderungen des Anhangs zur Anlage 1 der eVV. Das Reviewergebnis - zu diesem Mappingkonzept - von der IHE-AG IHE-XDS ValueSets aus 2023 wurde berücksichtigt.",
  "copyright" : "2025 DVMD e.V.",
  "sourceUri" : "http://dvmd.de/fhir/ValueSet/kdl",
  "targetUri" : "http://ihe-d.de/ValueSets/IHEXDSclassCode",
  "group" : [
    {
      "source" : "http://dvmd.de/fhir/CodeSystem/kdl",
      "target" : "http://ihe-d.de/CodeSystems/IHEXDSclassCode",
      "element" : [
        {
          "code" : "AD010101",
          "display" : "Ärztliche Stellungnahme",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010102",
          "display" : "Durchgangsarztbericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010103",
          "display" : "Entlassungsbericht intern",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010104",
          "display" : "Entlassungsbericht extern",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010105",
          "display" : "Reha-Bericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010106",
          "display" : "Verlegungsbericht intern",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010107",
          "display" : "Verlegungsbericht extern",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010108",
          "display" : "Vorläufiger Arztbericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010109",
          "display" : "Ärztlicher Befundbericht",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010110",
          "display" : "Ärztlicher Verlaufsbericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010111",
          "display" : "Ambulanzbrief",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010112",
          "display" : "Kurzarztbrief",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010113",
          "display" : "Nachschaubericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010114",
          "display" : "Interventionsbericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010115",
          "display" : "Entlassungsbericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010116",
          "display" : "Verlegungsbericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010199",
          "display" : "Sonstiger Arztbericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020101",
          "display" : "Arbeitsunfähigkeitsbescheinigung",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020102",
          "display" : "Beurlaubung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020103",
          "display" : "Todesbescheinigung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020104",
          "display" : "Ärztliche Bescheinigung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020105",
          "display" : "Notfall-/Vertretungsschein",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020106",
          "display" : "Wiedereingliederungsplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020107",
          "display" : "Aufenthaltsbescheinigung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020108",
          "display" : "Geburtsanzeige",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020199",
          "display" : "Sonstige Bescheinigung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020201",
          "display" : "Anatomische Skizze",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020202",
          "display" : "Befundbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020203",
          "display" : "Bericht Gesundheitsuntersuchung",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020204",
          "display" : "Krebsfrüherkennung",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020205",
          "display" : "Messblatt",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020206",
          "display" : "Belastungserprobung",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020207",
          "display" : "Ärztlicher Fragebogen",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020208",
          "display" : "Befund extern",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020299",
          "display" : "Sonstige ärztliche Befunderhebung",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060101",
          "display" : "Konsilanforderung",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060102",
          "display" : "Konsilanmeldung",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060103",
          "display" : "Konsilbericht intern",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060104",
          "display" : "Konsilbericht extern",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060105",
          "display" : "Visitenprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060106",
          "display" : "Tumorkonferenzprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060107",
          "display" : "Teambesprechungsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060108",
          "display" : "Anordnung/Verordnung",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060109",
          "display" : "Verordnung",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060110",
          "display" : "Konsilbericht",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060199",
          "display" : "Sonstige Fallbesprechung",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010101",
          "display" : "Übersicht abrechnungsrelevanter Diagnosen / Prozeduren",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010102",
          "display" : "G-AEP Kriterien",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010103",
          "display" : "Kostenübernahmeverlängerung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010104",
          "display" : "Schriftverkehr MD Kasse",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010105",
          "display" : "Abrechnungsschein",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010106",
          "display" : "Rechnung ambulante/stationäre Behandlung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010107",
          "display" : "MD Prüfauftrag",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010108",
          "display" : "MD Gutachten",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010109",
          "display" : "Begründete Unterlagen Leistungskodierung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010110",
          "display" : "Heil- und Kostenplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010111",
          "display" : "Kostenvoranschlag",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010199",
          "display" : "Sonstige Abrechnungsdokumentation",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010201",
          "display" : "Antrag auf Rehabilitation",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010202",
          "display" : "Antrag auf Betreuung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010203",
          "display" : "Antrag auf gesetzliche Unterbringung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010204",
          "display" : "Verlängerungsantrag",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010205",
          "display" : "Antrag auf Psychotherapie",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010206",
          "display" : "Antrag auf Pflegeeinstufung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010207",
          "display" : "Kostenübernahmeantrag",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010208",
          "display" : "Antrag auf Leistungen der Pflegeversicherung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010209",
          "display" : "Antrag auf Kurzzeitpflege",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010210",
          "display" : "Antrag auf Fixierung/Isolierung beim Amtsgericht",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010211",
          "display" : "Antrag abrechnungsrelevante OPS-Kodes",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010299",
          "display" : "Sonstiger Antrag",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010301",
          "display" : "Anästhesieaufklärungsbogen",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010302",
          "display" : "Diagnostischer Aufklärungsbogen",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010303",
          "display" : "Operationsaufklärungsbogen",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010304",
          "display" : "Aufklärungsbogen Therapie",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010399",
          "display" : "Sonstiger Aufklärungsbogen",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030101",
          "display" : "Aktenlaufzettel",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030102",
          "display" : "Checkliste Entlassung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030103",
          "display" : "Entlassungsplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030104",
          "display" : "Patientenlaufzettel",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030199",
          "display" : "Sonstige Checkliste Administration",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050101",
          "display" : "Datenschutzerklärung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050102",
          "display" : "Einverständniserklärung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050103",
          "display" : "Erklärung Nichtansprechbarkeit Patienten",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050104",
          "display" : "Einverständniserklärung Abrechnung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050105",
          "display" : "Einverständniserklärung Behandlung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050106",
          "display" : "Einwilligung und Datenschutzerklärung Entlassungsmanagement",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050107",
          "display" : "Schweigepflichtentbindung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050108",
          "display" : "Entlassung gegen ärztlichen Rat",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050109",
          "display" : "Aufforderung zur Herausgabe der medizinischen Dokumentation",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050110",
          "display" : "Aufforderung zur Löschung der medizinischen Dokumentation",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050111",
          "display" : "Aufforderung zur Berichtigung der medizinischen Dokumentation",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050199",
          "display" : "Sonstige Einwilligung/Erklärung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160101",
          "display" : "Blutgruppenausweis",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160102",
          "display" : "Impfausweis",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160103",
          "display" : "Vorsorgevollmacht",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160104",
          "display" : "Patientenverfügung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160105",
          "display" : "Wertgegenständeverwaltung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160106",
          "display" : "Allergiepass",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160107",
          "display" : "Herzschrittmacherausweis",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160108",
          "display" : "Nachlassprotokoll",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160109",
          "display" : "Mutterpass (Kopie)",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160110",
          "display" : "Ausweiskopie",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160111",
          "display" : "Implantat-Ausweis",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160112",
          "display" : "Betreuerausweis",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160113",
          "display" : "Patientenbild",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160199",
          "display" : "Sonstiges patienteneigenes Dokument",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160201",
          "display" : "Belehrung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160202",
          "display" : "Informationsblatt",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160203",
          "display" : "Informationsblatt Entlassungsmanagement",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160299",
          "display" : "Sonstiges Patienteninformationsblatt",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160301",
          "display" : "Heil- / Hilfsmittelverordnung",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160302",
          "display" : "Krankentransportschein",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160303",
          "display" : "Verordnung häusliche Krankenpflege",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160399",
          "display" : "Sonstige poststationäre Verordnung",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170101",
          "display" : "Dokumentationsbogen Meldepflicht",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170102",
          "display" : "Hygienestandard",
          "target" : [
            {
              "code" : "GUT",
              "display" : "Gutachten und Qualitätsmanagement",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170103",
          "display" : "Patientenfragebogen",
          "target" : [
            {
              "code" : "GUT",
              "display" : "Gutachten und Qualitätsmanagement",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170104",
          "display" : "Pflegestandard",
          "target" : [
            {
              "code" : "GUT",
              "display" : "Gutachten und Qualitätsmanagement",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170105",
          "display" : "Qualitätssicherungsbogen",
          "target" : [
            {
              "code" : "GUT",
              "display" : "Gutachten und Qualitätsmanagement",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170199",
          "display" : "Sonstiges Qualitätssicherungsdokument",
          "target" : [
            {
              "code" : "GUT",
              "display" : "Gutachten und Qualitätsmanagement",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190101",
          "display" : "Anforderung Unterlagen",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190102",
          "display" : "Schriftverkehr Amtsgericht",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190103",
          "display" : "Schriftverkehr MD Arzt",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190104",
          "display" : "Schriftverkehr Krankenkasse",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190105",
          "display" : "Schriftverkehr Deutsche Rentenversicherung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190106",
          "display" : "Sendebericht",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190107",
          "display" : "Empfangsbestätigung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190108",
          "display" : "Handschriftliche Notiz",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190109",
          "display" : "Lieferschein",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190110",
          "display" : "Schriftverkehr Amt/Gericht/Anwalt",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190111",
          "display" : "Schriftverkehr Strafverfolgung und Schadensersatz",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190112",
          "display" : "Anforderung Unterlagen MD",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190113",
          "display" : "Widerspruchsbegründung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190114",
          "display" : "Schriftverkehr Unfallversicherungsträger und Leistungserbringer",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190199",
          "display" : "Sonstiger Schriftverkehr",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190201",
          "display" : "Beratungsbogen Sozialer Dienst",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190202",
          "display" : "Soziotherapeutischer Betreuungsplan",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190203",
          "display" : "Einschätzung Sozialdienst",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190204",
          "display" : "Abschlussbericht Sozialdienst",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190299",
          "display" : "Sonstiges Dokument Sozialdienst",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220101",
          "display" : "Behandlungsvertrag",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220102",
          "display" : "Wahlleistungsvertrag",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220103",
          "display" : "Heimvertrag",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220104",
          "display" : "Angaben zur Vergütung von Mitarbeitenden",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220199",
          "display" : "Sonstiger Vertrag",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010101",
          "display" : "Anamnesebogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010102",
          "display" : "Anmeldung Aufnahme",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010103",
          "display" : "Aufnahmebogen",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010104",
          "display" : "Checkliste Aufnahme",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010105",
          "display" : "Stammblatt",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010199",
          "display" : "Sonstige Aufnahmedokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050101",
          "display" : "Verordnung von Krankenhausbehandlung",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050102",
          "display" : "Überweisungsschein",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050103",
          "display" : "Überweisungsschein Entlassung",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050104",
          "display" : "Verlegungsschein Intern",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050199",
          "display" : "Sonstiges Einweisungs-/Überweisungsdokument",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190101",
          "display" : "Einsatzprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190102",
          "display" : "Notaufnahmebericht",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190103",
          "display" : "Notaufnahmebogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190104",
          "display" : "Notfalldatensatz",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190105",
          "display" : "ISAR Screening",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190199",
          "display" : "Sonstige Dokumentation Rettungsstelle",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020101",
          "display" : "Anforderung bildgebende Diagnostik",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020102",
          "display" : "Angiographiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020103",
          "display" : "CT-Befund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020104",
          "display" : "Echokardiographiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020105",
          "display" : "Endoskopiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020106",
          "display" : "Herzkatheterprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020107",
          "display" : "MRT-Befund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020108",
          "display" : "OCT-Befund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020109",
          "display" : "PET-Befund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020110",
          "display" : "Röntgenbefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020111",
          "display" : "Sonographiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020112",
          "display" : "SPECT-Befund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020113",
          "display" : "Szintigraphiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020114",
          "display" : "Mammographiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020115",
          "display" : "Checkliste bildgebende Diagnostik",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020199",
          "display" : "Sonstige Dokumentation bildgebende Diagnostik",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060101",
          "display" : "Anforderung Funktionsdiagnostik",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060102",
          "display" : "Audiometriebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060103",
          "display" : "Befund evozierter Potentiale",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060104",
          "display" : "Blutdruckprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060105",
          "display" : "CTG-Ausdruck",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060106",
          "display" : "Dokumentationsbogen Feststellung Hirntod",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060107",
          "display" : "Dokumentationsbogen Herzschrittmacherkontrolle",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060108",
          "display" : "Dokumentationsbogen Lungenfunktionsprüfung",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060109",
          "display" : "EEG-Auswertung",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060110",
          "display" : "EMG-Befund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060111",
          "display" : "EKG-Auswertung",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060112",
          "display" : "Manometriebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060113",
          "display" : "Messungsprotokoll Augeninnendruck",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060114",
          "display" : "Neurographiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060115",
          "display" : "Rhinometriebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060116",
          "display" : "Schlaflabordokumentationsbogen",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060117",
          "display" : "Schluckuntersuchung",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060118",
          "display" : "Checkliste Funktionsdiagnostik",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060119",
          "display" : "Ergometriebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060120",
          "display" : "Kipptischuntersuchung",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060121",
          "display" : "Augenuntersuchung",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060122",
          "display" : "Dokumentationsbogen ICD-Kontrolle",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060123",
          "display" : "Zystometrie",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060124",
          "display" : "Uroflowmetrie",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060199",
          "display" : "Sonstige Dokumentation Funktionsdiagnostik",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060201",
          "display" : "Schellong Test",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060202",
          "display" : "H2 Atemtest",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060203",
          "display" : "Allergietest",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060204",
          "display" : "Zahlenverbindungstest",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060205",
          "display" : "6-Minuten-Gehtest",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060209",
          "display" : "Sonstige Funktionstests",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060299",
          "display" : "Sonstiger Funktionstest",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED010199",
          "display" : "Sonstige Audiodokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020101",
          "display" : "Fotodokumentation Operation",
          "target" : [
            {
              "code" : "BIL",
              "display" : "Bilddaten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020102",
          "display" : "Fotodokumentation Dermatologie",
          "target" : [
            {
              "code" : "BIL",
              "display" : "Bilddaten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020103",
          "display" : "Fotodokumentation Diagnostik",
          "target" : [
            {
              "code" : "BIL",
              "display" : "Bilddaten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020104",
          "display" : "Videodokumentation Operation",
          "target" : [
            {
              "code" : "VID",
              "display" : "Videodaten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020199",
          "display" : "Foto-/Videodokumentation Sonstige",
          "target" : [
            {
              "code" : "BIL",
              "display" : "Bilddaten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110101",
          "display" : "Behandlungspfad",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110102",
          "display" : "Notfalldatenmanagement (NFDM)",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110103",
          "display" : "Medikationsplan elektronisch (eMP)",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110104",
          "display" : "eArztbrief",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110105",
          "display" : "eImpfpass",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110106",
          "display" : "eZahnärztliches Bonusheft",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110107",
          "display" : "eArbeitsunfähigkeitsbescheinigung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110108",
          "display" : "eRezept",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110109",
          "display" : "Pflegebericht",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110110",
          "display" : "eDMP",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110111",
          "display" : "eMutterpass",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110112",
          "display" : "KH-Entlassbrief",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110113",
          "display" : "U-Heft Untersuchungen",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110114",
          "display" : "U-Heft Teilnahmekarte",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110115",
          "display" : "U-Heft Elternnotiz",
          "target" : [
            {
              "code" : "AUS",
              "display" : "Medizinischer Ausweis",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110116",
          "display" : "Überleitungsbogen",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110199",
          "display" : "Sonstige Dokumentation KIS",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190101",
          "display" : "E-Mail Befundauskunft",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190102",
          "display" : "E-Mail Juristische Beweissicherung",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190103",
          "display" : "E-Mail Arztauskunft",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190104",
          "display" : "E-Mail Sonstige",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190105",
          "display" : "Fax Befundauskunft",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190106",
          "display" : "Fax Juristische Beweissicherung",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190107",
          "display" : "Fax Arztauskunft",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190108",
          "display" : "Fax Sonstige",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190199",
          "display" : "Sonstiger elektronischer Schriftverkehr",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020101",
          "display" : "Blutgasanalyse",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020102",
          "display" : "Blutkulturenbefund",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020103",
          "display" : "Herstellungs- und Prüfprotokoll von Blut und Blutprodukten",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020104",
          "display" : "Serologischer Befund",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020199",
          "display" : "Sonstige Dokumentation Blut",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120101",
          "display" : "Glukosetoleranztestprotokoll",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120102",
          "display" : "Laborbefund extern",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120103",
          "display" : "Laborbefund intern",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120104",
          "display" : "Anforderung Labor",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120105",
          "display" : "Überweisungsschein Labor",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120106",
          "display" : "Hämatologisches Speziallabor",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120107",
          "display" : "Laborbefund",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120199",
          "display" : "Sonstiger Laborbefund",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB130101",
          "display" : "Mikrobiologiebefund",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB130102",
          "display" : "Urinbefund",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB220101",
          "display" : "Befund über positive Infektionsmarker",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB220102",
          "display" : "Virologiebefund",
          "target" : [
            {
              "code" : "LAB",
              "display" : "Laborergebnisse",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010101",
          "display" : "Intraoperative Anästhesiedokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010102",
          "display" : "Aufwachraumprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010103",
          "display" : "Checkliste Anästhesie",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010104",
          "display" : "Präoperative Anästhesiedokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010105",
          "display" : "Postoperative Anästhesiedokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010199",
          "display" : "Sonstige Anästhesiedokumentation",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150101",
          "display" : "Chargendokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150102",
          "display" : "OP-Anmeldungsbogen",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150103",
          "display" : "OP-Bericht",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150104",
          "display" : "OP-Bilddokumentation",
          "target" : [
            {
              "code" : "BIL",
              "display" : "Bilddaten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150105",
          "display" : "OP-Checkliste",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150106",
          "display" : "OP-Protokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150107",
          "display" : "Postoperative Verordnung",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150108",
          "display" : "OP-Zählprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150109",
          "display" : "Dokumentation ambulantes Operieren",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150199",
          "display" : "Sonstige OP-Dokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP200101",
          "display" : "Transplantationsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP200102",
          "display" : "Spenderdokument",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP200199",
          "display" : "Sonstige Transplantationsdokumentation",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT080101",
          "display" : "Histologieanforderung",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT080102",
          "display" : "Histologiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT130101",
          "display" : "Molekularpathologieanforderung",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT130102",
          "display" : "Molekularpathologiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT230199",
          "display" : "Sonstige pathologische Dokumentation",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT260101",
          "display" : "Zytologieanforderung",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT260102",
          "display" : "Zytologiebefund",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070101",
          "display" : "Geburtenbericht",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070102",
          "display" : "Geburtenprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070103",
          "display" : "Geburtenverlaufskurve",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070104",
          "display" : "Neugeborenenscreening",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070105",
          "display" : "Partogramm",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070106",
          "display" : "Wiegekarte",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070107",
          "display" : "Neugeborenendokumentationsbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070108",
          "display" : "Säuglingskurve",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070109",
          "display" : "Geburtenbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070110",
          "display" : "Perzentilkurve",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070111",
          "display" : "Entnahme Nabelschnurblut",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070112",
          "display" : "Datenblatt für den Pädiater",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070199",
          "display" : "Sonstige Geburtendokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070201",
          "display" : "Barthel Index",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070202",
          "display" : "Dem Tect",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070203",
          "display" : "ISAR Screening",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070204",
          "display" : "Sturzrisikoerfassungsbogen",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070205",
          "display" : "Geriatrische Depressionsskala",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070206",
          "display" : "Geriatrische Assessmentdokumentation",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070207",
          "display" : "Mobilitätstest nach Tinetti",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070208",
          "display" : "Timed Up and Go Test",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070299",
          "display" : "Sonstiges geriatrisches Dokument",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110101",
          "display" : "Geriatrische Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110102",
          "display" : "Intensivmedizinische Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110103",
          "display" : "MRE/Nicht-MRE Komplexbehandlung",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110104",
          "display" : "Neurologische Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110105",
          "display" : "Palliativmedizinische Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110106",
          "display" : "PKMS-Dokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110107",
          "display" : "Dokumentation COVID",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110199",
          "display" : "Sonstige Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130101",
          "display" : "Vertrag Maßregelvollzug",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130102",
          "display" : "Antrag Maßregelvollzug",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130103",
          "display" : "Schriftverkehr Maßregelvollzug",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130104",
          "display" : "Einwilligung/Einverständniserklärung Maßregelvollzug",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130199",
          "display" : "Sonstiges Maßregelvollzugdokument",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150101",
          "display" : "Follow up-Bogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150102",
          "display" : "Meldebogen Krebsregister",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150103",
          "display" : "Tumorkonferenzprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150104",
          "display" : "Tumorlokalisationsbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150199",
          "display" : "Sonstiger onkologischer Dokumentationsbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160101",
          "display" : "Patientenaufzeichnungen",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160102",
          "display" : "Testpsychologische Diagnostik",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160103",
          "display" : "Psychiatrisch-psychotherapeutische Therapieanordnung",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160104",
          "display" : "Psychiatrisch-psychotherapeutische Therapiedokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160105",
          "display" : "Psychiatrisch-psychotherapeutischer Verlaufsbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160106",
          "display" : "Spezialtherapeutische Verlaufsdokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160107",
          "display" : "Therapieeinheiten Ärzte/Psychologen/Spezialtherapeuten",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160108",
          "display" : "1:1 Betreuung/Einzelbetreuung/Psychiatrische Intensivbehandlung",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160109",
          "display" : "Checkliste für die Unterbringung psychisch Kranker",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160110",
          "display" : "Dokumentation Verhaltensanalyse",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160111",
          "display" : "Dokumentation Depression",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160112",
          "display" : "Dokumentation Stationsäquivalente Behandlung (StäB)",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160199",
          "display" : "Sonstiges psychiatrisch-psychotherapeutisches Dokument",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF060101",
          "display" : "Forschungsbericht",
          "target" : [
            {
              "code" : "FOR",
              "display" : "Forschung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF060199",
          "display" : "Sonstige Forschungsdokumentation",
          "target" : [
            {
              "code" : "FOR",
              "display" : "Forschung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190101",
          "display" : "CRF-Bogen",
          "target" : [
            {
              "code" : "FOR",
              "display" : "Forschung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190102",
          "display" : "Einwilligung Studie",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190103",
          "display" : "Protokoll Ein- und Ausschlusskriterien",
          "target" : [
            {
              "code" : "FOR",
              "display" : "Forschung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190104",
          "display" : "Prüfplan",
          "target" : [
            {
              "code" : "FOR",
              "display" : "Forschung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190105",
          "display" : "SOP-Bogen",
          "target" : [
            {
              "code" : "FOR",
              "display" : "Forschung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190106",
          "display" : "Studienbericht",
          "target" : [
            {
              "code" : "FOR",
              "display" : "Forschung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190199",
          "display" : "Sonstige Studiendokumentation",
          "target" : [
            {
              "code" : "FOR",
              "display" : "Forschung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020101",
          "display" : "Bestrahlungsplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020102",
          "display" : "Bestrahlungsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020103",
          "display" : "Bestrahlungsverordnung",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020104",
          "display" : "Radiojodtherapieprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020105",
          "display" : "Therapieprotokoll mit Radionukliden",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020199",
          "display" : "Sonstiges Bestrahlungstherapieprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060101",
          "display" : "Ergotherapieprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060102",
          "display" : "Logopädieprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060103",
          "display" : "Physiotherapieprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060104",
          "display" : "Anforderung Funktionstherapie",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060105",
          "display" : "Elektrokonvulsionstherapie",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060106",
          "display" : "Transkranielle Magnetstimulation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060199",
          "display" : "Sonstiges Funktionstherapieprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130101",
          "display" : "Anforderung Medikation",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130102",
          "display" : "Arzneimitteladministration",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130103",
          "display" : "Chemotherapieprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130104",
          "display" : "Hormontherapieprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130105",
          "display" : "Medikamentenplan extern",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130106",
          "display" : "Medikamentenplan intern/extern (mit BTM)",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130107",
          "display" : "Medikationsplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130108",
          "display" : "Rezept",
          "target" : [
            {
              "code" : "VER",
              "display" : "Verordnung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130109",
          "display" : "Schmerztherapieprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130110",
          "display" : "Prämedikationsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130111",
          "display" : "Lyse Dokument",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130199",
          "display" : "Sonstiges Dokument medikamentöser Therapie",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH160101",
          "display" : "Protokoll Ernährungsberatung",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH160102",
          "display" : "Apotheke Patientenberatung",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH160199",
          "display" : "Sonstiges Protokoll Patientenschulung",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200101",
          "display" : "Anforderung Blutkonserven",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200102",
          "display" : "Blutspendeprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200103",
          "display" : "Bluttransfusionsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200104",
          "display" : "Konservenbegleitschein",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200199",
          "display" : "Sonstiges Transfusionsdokument",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH230199",
          "display" : "Sonstige Therapiedokumentation",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB999996",
          "display" : "Nachweise (Zusatz-) Entgelte",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB999999",
          "display" : "Sonstige medizinische Dokumentation",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010101",
          "display" : "Dekubitusrisikoeinschätzung",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010102",
          "display" : "Mini Mental Status Test inkl. Uhrentest",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010103",
          "display" : "Schmerzerhebungsbogen",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010104",
          "display" : "Ernährungsscreening",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010105",
          "display" : "Aphasiescreening",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010106",
          "display" : "Glasgow Coma Scale",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010107",
          "display" : "NIH Stroke Scale",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010108",
          "display" : "IPSS (Internationaler Prostata Symptom Score)",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010199",
          "display" : "Sonstiger Assessmentbogen",
          "target" : [
            {
              "code" : "ASM",
              "display" : "Assessment",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010201",
          "display" : "Apotheke Entlassbericht",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010202",
          "display" : "Apotheke Betreuungsplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010203",
          "display" : "Arzneimittelinformation",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010204",
          "display" : "Apotheke Validierung",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010205",
          "display" : "Apotheke Visitenprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010206",
          "display" : "AMTS-Prüfbericht",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010207",
          "display" : "Apotheke Interventionsbericht",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010208",
          "display" : "Arzneimittelabgabe",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010299",
          "display" : "Sonstige Apothekendokumentation",
          "target" : [
            {
              "code" : "ADM",
              "display" : "Administratives Dokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040101",
          "display" : "Diabetiker Kurve",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040102",
          "display" : "Insulinplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040199",
          "display" : "Sonstige Diabetesdokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040201",
          "display" : "Dialyseanforderung",
          "target" : [
            {
              "code" : "ANF",
              "display" : "Anforderung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040202",
          "display" : "Dialyseprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040299",
          "display" : "Sonstige Dialysedokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040301",
          "display" : "Ein- und Ausfuhrprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040302",
          "display" : "Fixierungsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040303",
          "display" : "Isolierungsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040304",
          "display" : "Lagerungsplan",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040305",
          "display" : "Punktionsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040306",
          "display" : "Punktionsprotokoll therapeutisch",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040307",
          "display" : "Reanimationsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040308",
          "display" : "Sondenplan",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040309",
          "display" : "Behandlungsplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040310",
          "display" : "Infektionsdokumentationsbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040311",
          "display" : "Nosokomialdokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040312",
          "display" : "Stomadokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040313",
          "display" : "Katheterdokument",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040314",
          "display" : "Kardioversion",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040399",
          "display" : "Sonstiger Durchführungsnachweis",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090101",
          "display" : "Beatmungsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090102",
          "display" : "Intensivkurve",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090103",
          "display" : "Intensivpflegebericht",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090104",
          "display" : "Monitoringausdruck",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090105",
          "display" : "Intensivdokumentationsbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090199",
          "display" : "Sonstiger Intensivdokumentationsbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160101",
          "display" : "Auszug aus den medizinischen Daten",
          "target" : [
            {
              "code" : "DOK",
              "display" : "Dokumente ohne besondere Form (Notizen)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160102",
          "display" : "Ernährungsplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160103",
          "display" : "Meldebogen Krebsregister",
          "target" : [
            {
              "code" : "GUT",
              "display" : "Gutachten und Qualitätsmanagement",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160104",
          "display" : "Pflegeanamnesebogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160105",
          "display" : "Pflegebericht",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160106",
          "display" : "Pflegekurve",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160107",
          "display" : "Pflegeplanung",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160108",
          "display" : "Pflegeüberleitungsbogen",
          "target" : [
            {
              "code" : "BRI",
              "display" : "Brief",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160109",
          "display" : "Sturzprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160110",
          "display" : "Überwachungsprotokoll",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160111",
          "display" : "Verlaufsdokumentationsbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160112",
          "display" : "Pflegevisite",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160113",
          "display" : "Fallbesprechung Bezugspflegekraft",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160114",
          "display" : "Pflegenachweis",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160115",
          "display" : "Fotodokumentation Dekubitus",
          "target" : [
            {
              "code" : "BIL",
              "display" : "Bilddaten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160199",
          "display" : "Sonstiger Pflegedokumentationsbogen",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL230101",
          "display" : "Wunddokumentationsbogen",
          "target" : [
            {
              "code" : "BEF",
              "display" : "Befundbericht",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL230102",
          "display" : "Bewegungs- und Lagerungsplan",
          "target" : [
            {
              "code" : "PLA",
              "display" : "Planungsdokument",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL230103",
          "display" : "Fotodokumentation Wunden",
          "target" : [
            {
              "code" : "BIL",
              "display" : "Bilddaten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL230199",
          "display" : "Sonstige Wunddokumentation",
          "target" : [
            {
              "code" : "DUR",
              "display" : "Durchführungsprotokoll",
              "equivalence" : "wider"
            }
          ]
        }
      ]
    },
    {
      "source" : "http://dvmd.de/fhir/CodeSystem/kdl",
      "target" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
      "element" : [
        {
          "code" : "UB140101",
          "display" : "Behördliche Genehmigung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140102",
          "display" : "Dokumentation vorhandender Infrastruktur",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140199",
          "display" : "Sonstiger Nachweis Infrastruktur",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140201",
          "display" : "Berufserlaubnis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140202",
          "display" : "Approbation",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140203",
          "display" : "Arbeitsvertrag",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140204",
          "display" : "Arbeitszeugnis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140205",
          "display" : "Dienstleistungsvereinbarung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140206",
          "display" : "Dienstplan",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140207",
          "display" : "Weiterbildungs-/Fortbildungs-/Qualifikationsnachweis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140208",
          "display" : "Ausbildungsbefugnis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140209",
          "display" : "Personalliste",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140210",
          "display" : "Auszug aus der Personalakte",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140211",
          "display" : "PuPGV-Nachweis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140299",
          "display" : "Sonstiger Nachweis Personal",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140301",
          "display" : "Arzneimittelliste",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140302",
          "display" : "Inventarliste",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140303",
          "display" : "Medizinproduktebuch",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140304",
          "display" : "Geräteeinweisung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140399",
          "display" : "Sonstiger Nachweis sachliche Ausstattung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140401",
          "display" : "Aufstellung erbrachte Leistungen",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140402",
          "display" : "Aufstellung medizinische Angebote",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140403",
          "display" : "Dokumentation Behandlungsprogramm",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140404",
          "display" : "Fallliste",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140405",
          "display" : "Hygieneplan",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140406",
          "display" : "Organigramm",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140407",
          "display" : "Verfahrensanweisung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140408",
          "display" : "Dienstanweisung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140409",
          "display" : "Zertifizierungsurkunde",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140499",
          "display" : "Sonstiger Nachweis Prozesse",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB999997",
          "display" : "Gesamtdokumentation stationäre Versorgung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB999998",
          "display" : "Gesamtdokumentation ambulante Versorgung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        }
      ]
    }
  ]
}

```
